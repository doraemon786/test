package com.cg.springplp.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="customer")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="customer_id")
	private int customerId;
	@Column(name="customer_name")
	@NotBlank(message="This field can't be empty")
	private String customerName;
	@Column(name="customer_email")
	@Email
	@NotBlank(message="This field can't be empty")
	private String customerEmail;
	@Column(name="customer_pwd")
	@NotBlank(message="This field can't be empty")
	@Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})")
	private String customerPwd;
	@Column(name="customer_mobile")
	@Digits(integer=10,fraction=0,message="Length should be only 10" )
	@NotBlank(message="This field can't be empty")
	private String customerMobile;
	@NotBlank(message="This field can't be empty")
	private List<String> address = new ArrayList<String>() ;

	@Column(name="wishlist")
	@OneToMany(cascade = CascadeType.ALL)
	private List<Product> wishList = new ArrayList<Product>();
	@Column(name="orders")
	@OneToMany(cascade = CascadeType.ALL)
	private List<CustomerOrder> orders = new ArrayList<CustomerOrder>();
	@OneToOne(cascade=CascadeType.ALL)
	private Cart cart;
	
	
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPwd() {
		return customerPwd;
	}
	public void setCustomerPwd(String customerPwd) {
		this.customerPwd = customerPwd;
	}
	public String getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}
	public List<Product> getWishList() {
		return wishList;
	}
	public void setWishList(Product wish) {
		this.wishList.add(wish);
	}
	public List<CustomerOrder> getOrderedItems() {
		return orders;
	}
	public void setOrderedItems(CustomerOrder order) {
		this.orders.add(order);
	}
	public List<String> getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address.add(address);
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail="
				+ customerEmail + ", customerPwd=" + customerPwd + ", customerMobile=" + customerMobile + ", address="
				+ address + ", wishList=" + wishList + ", orders=" + orders + ", cart=" + cart + "]";
	}
	

	
}
