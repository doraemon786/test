package com.cg.springplp.model;

public enum ProductCategory {

	BOOKS,
	ELECTRONICS,
	FASHION,
	HOME_AND_FURNISHINING,
	PERSONAL_CARE,
	SPORTS,
	OTHERS
}
