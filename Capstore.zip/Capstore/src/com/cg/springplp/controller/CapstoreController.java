package com.cg.springplp.controller;

public class CapstoreController {

}
