package com.cg.springplp.exception;

public class CapstoreException extends Exception 
{

	public CapstoreException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
